//1 In programming, what is the opposite of black?

//2 In programming, what is the opposite of x > y ?

//3 Given an array of numbers, add up all the elements
var a = [5,6,7,5433,543,53,535,53,543,543,23,412,34,45];



//Write a function has1337s which takes an array and 
//returns true if the array contains the number 1337
function has1337s(arr){

}

/*Write a function that receives an array and another parameter.
It will return true if one of the elements of the array is 
equal to the other param. It should return false otherwise */
function containsThing(arr,theThing){
    
}

/*Write a function that receives an array and another parameter.
It will return true if NONE of the elements of the array is 
equal to the other param. It should return false otherwise */
function doesntContain(arr, theThing){
    
}


/*Write a function that receives an array of numbers and returns
the average of those numbers*/
function getAvg(arr){
    
}



// Write a function which draws a star triangle based
//on an input number
// starz(2) = 
// **
// *
//starz(4) =
// ****
// ***
// **
// *


