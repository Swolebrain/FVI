function dieRoll(){
    //rolls a single die, returns number between 1 and 6
}

function diceRoll(numDice){
    //rolls as many dice as numDice says, returns an array
    //with the rolls
}

function swapEnds(arr){
    //swap the first and last elements of the input array
    //then return
}

